export var location;

export function saveLocation(loc) {
  location = loc;
}

export function getLocation() {
  return location;
}
