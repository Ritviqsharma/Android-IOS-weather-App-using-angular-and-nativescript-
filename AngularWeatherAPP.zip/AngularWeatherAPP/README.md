#Install the Required  dependencies and Quick Setup Guide

1-Install the NativeScript CLI and setup (By following steps Provided in this link https://docs.nativescript.org/start/quick-setup?_ga=2.101912641.1719639437.1590476247-1424407080.1590476247)
2-Install All the Mentioned Dependencies in the document.
3-I suggest you to also install Android Studio For the ease of Emulator Startup which is required when we run our App in Android OS.
4-Also a IDE of Your Choice.
5-Install the NativeScript Preview and Developer App in you Android mobile also.
6-Run "tns" command for Integrity checking.

# NativeScript Angular Weather app


-->This repo serves as the starting point for building the part of the [NativeScript Angular Getting Started Guide].

-->Please file any issues with this template on the [NativeScript/docs repository], which is where the tutorial content lives.

-->For any Help or issue Resolvance while Setup Visit the Nativescript community to resolve them

-->Scan the code showing on the the developer program and scan it in your Mobile for Running and Previewing It

-->Develop the project with more hardwork and Hope You like my Project,Sorry for the trivial mistakes if you find that because it can be developed in veryu short time span.

-->I use little bit Groceries template here because Weather Templates showing error Because of time boundation i cant be able to solve that issue now so i apologize for that.

-->Thanking You,Hope you will Like the project.
